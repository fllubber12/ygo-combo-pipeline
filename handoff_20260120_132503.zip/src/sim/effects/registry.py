from __future__ import annotations

from ..errors import SimModelError
from ..state import GameState
from .demo_effects import DEMO_EXTENDER_CID, DemoExtenderEffect
from .fiendsmith_effects import (
    FIENDSMITH_ENGRAVER_CID,
    FIENDSMITH_LACRIMA_CRIMSON_CID,
    FIENDSMITH_AGNUMDAY_CID,
    FIENDSMITH_DESIRAE_CID,
    FIENDSMITH_PARADISE_CID,
    FIENDSMITH_REQUIEM_CID,
    FIENDSMITH_SANCT_CID,
    FIENDSMITH_TRACT_CID,
    FiendsmithDesiraeEffect,
    FiendsmithEngraverEffect,
    FiendsmithLacrimaCrimsonEffect,
    FiendsmithAgnumdayEffect,
    FiendsmithParadiseEffect,
    FiendsmithRequiemEffect,
    FiendsmithSanctEffect,
    FiendsmithTractEffect,
)
from .types import EffectAction, EffectImpl

EFFECT_REGISTRY: dict[str, EffectImpl] = {}


def register_effect(cid: str, effect: EffectImpl) -> None:
    EFFECT_REGISTRY[cid] = effect


def enumerate_effect_actions(state: GameState) -> list[EffectAction]:
    cids = set()
    for card in state.hand:
        cids.add(card.cid)
    for card in state.field.mz:
        if card:
            cids.add(card.cid)
    for card in state.field.emz:
        if card:
            cids.add(card.cid)
    for card in state.gy:
        cids.add(card.cid)

    actions: list[EffectAction] = []
    for cid in sorted(cids):
        effect = EFFECT_REGISTRY.get(cid)
        if not effect:
            continue
        effect_actions = effect.enumerate_actions(state)
        for action in effect_actions:
            if action.cid not in EFFECT_REGISTRY:
                raise SimModelError(f"Unregistered CID in action: {action.cid}")
            actions.append(action)

    actions.sort(key=lambda action: action.sort_key)
    return actions


def apply_effect_action(state: GameState, action: EffectAction) -> GameState:
    effect = EFFECT_REGISTRY.get(action.cid)
    if not effect:
        raise SimModelError(f"No effect registered for CID {action.cid}")
    return effect.apply(state, action)


register_effect(DEMO_EXTENDER_CID, DemoExtenderEffect())
register_effect(FIENDSMITH_ENGRAVER_CID, FiendsmithEngraverEffect())
register_effect(FIENDSMITH_TRACT_CID, FiendsmithTractEffect())
register_effect(FIENDSMITH_SANCT_CID, FiendsmithSanctEffect())
register_effect(FIENDSMITH_REQUIEM_CID, FiendsmithRequiemEffect())
register_effect(FIENDSMITH_LACRIMA_CRIMSON_CID, FiendsmithLacrimaCrimsonEffect())
register_effect(FIENDSMITH_AGNUMDAY_CID, FiendsmithAgnumdayEffect())
register_effect(FIENDSMITH_PARADISE_CID, FiendsmithParadiseEffect())
register_effect(FIENDSMITH_DESIRAE_CID, FiendsmithDesiraeEffect())
