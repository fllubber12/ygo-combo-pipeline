from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Any

from combos.endboard_evaluator import evaluate_endboard

from .actions import Action, apply_action, generate_actions
from .convert import game_state_to_endboard_snapshot
from .errors import IllegalActionError
from .effects.registry import apply_effect_action, enumerate_effect_actions
from .effects.types import EffectAction
from .effects.fiendsmith_effects import is_light_fiend_card, is_link_monster
from .state import GameState

BUIO_DAWNS_LIGHT_CID = "21624"
MUTINY_IN_THE_SKY_CID = "21626"
LUCE_DUSKS_DARK_CID = "21625"
AERIAL_EATER_CID = "20427"
FIENDSMITH_SEQUENCE_ALT_CID = "20226"

EQUIP_EFFECT_IDS = {
    "equip_sequence_to_fiend",
    "equip_requiem_to_fiend",
    "sequence_20226_equip",
}


@dataclass
class SearchResult:
    actions: list[Action | EffectAction]
    final_state: GameState
    evaluation: dict[str, Any]


def score_key(evaluation: dict[str, Any]) -> tuple[int, int, int]:
    has_s, has_a, count_b = evaluation["rank_key"]
    return (int(has_s), int(has_a), int(count_b))


def state_hash(state: GameState) -> tuple:
    def from_extra_flag(card) -> bool:
        if card.metadata.get("from_extra"):
            return True
        try:
            return int(card.metadata.get("link_rating", 0)) > 0
        except (TypeError, ValueError):
            return False

    def zone_names(cards):
        return tuple(
            (card.cid, card.properly_summoned, from_extra_flag(card))
            for card in cards
        )

    def freeze(value):
        if isinstance(value, dict):
            return tuple(sorted((key, freeze(val)) for key, val in value.items()))
        if isinstance(value, list):
            return tuple(freeze(item) for item in value)
        if isinstance(value, set):
            return tuple(sorted(freeze(item) for item in value))
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        return str(value)

    field_mz = tuple(
        (
            card.cid,
            card.properly_summoned,
            from_extra_flag(card),
            tuple(sorted(eq.cid for eq in card.equipped)),
        )
        if card
        else ("", False, False, ())
        for card in state.field.mz
    )
    field_emz = tuple(
        (
            card.cid,
            card.properly_summoned,
            from_extra_flag(card),
            tuple(sorted(eq.cid for eq in card.equipped)),
        )
        if card
        else ("", False, False, ())
        for card in state.field.emz
    )

    return (
        zone_names(state.deck),
        zone_names(state.hand),
        zone_names(state.gy),
        zone_names(state.banished),
        zone_names(state.extra),
        field_mz,
        field_emz,
        state.turn_number,
        state.phase,
        state.normal_summon_set_used,
        freeze(state.opt_used),
        freeze(state.restrictions),
        freeze(state.events),
        freeze(state.last_moved_to_gy),
    )


def core_action_sort_key(action: Action) -> tuple:
    items = []
    for key in sorted(action.params):
        value = action.params[key]
        if isinstance(value, list):
            value = tuple(value)
        items.append((key, value))
    return (action.action_type, tuple(items))


def _is_main_phase(state: GameState) -> bool:
    return str(state.phase).lower().startswith("main")


def _is_fiend_card(card) -> bool:
    race = str(card.metadata.get("race", "")).upper()
    if "FIEND" in race:
        return True
    return is_light_fiend_card(card)


def _derive_last_moved_to_gy(prev_state: GameState, new_state: GameState) -> list[str]:
    prev_counts = Counter(card.cid for card in prev_state.gy)
    new_counts = Counter(card.cid for card in new_state.gy)
    added: list[str] = []
    for cid in sorted(set(prev_counts) | set(new_counts)):
        diff = new_counts[cid] - prev_counts[cid]
        if diff > 0:
            added.extend([cid] * diff)
    return added


def _add_derived_events(state: GameState) -> GameState:
    derived: list[str] = []
    events = list(state.events)

    if (
        "MUTINY_FUSION_TRIGGER" not in events
        and not state.opt_used.get(f"{MUTINY_IN_THE_SKY_CID}:e1")
        and _is_main_phase(state)
    ):
        if any(card.cid == MUTINY_IN_THE_SKY_CID for card in state.hand):
            if state.open_mz_indices():
                if any(card.cid == LUCE_DUSKS_DARK_CID for card in state.extra):
                    if any(card.cid == AERIAL_EATER_CID for card in state.gy) and any(
                        card.cid == BUIO_DAWNS_LIGHT_CID for card in state.gy
                    ):
                        derived.append("MUTINY_FUSION_TRIGGER")

    if (
        "BUIO_TRIGGER" not in events
        and not state.opt_used.get(f"{BUIO_DAWNS_LIGHT_CID}:e1")
        and _is_main_phase(state)
    ):
        if any(card.cid == BUIO_DAWNS_LIGHT_CID for card in state.hand):
            if state.open_mz_indices() and any(_is_fiend_card(card) for card in state.field.mz if card):
                derived.append("BUIO_TRIGGER")

    if (
        "LUCE_TRIGGER" not in events
        and not state.opt_used.get(f"{LUCE_DUSKS_DARK_CID}:e1")
        and _is_main_phase(state)
    ):
        luce_entries = [
            (zone, idx, card)
            for zone, idx, card in state.field_cards()
            if card.cid == LUCE_DUSKS_DARK_CID
            and card.properly_summoned
            and str(card.metadata.get("summon_type", "")).lower() == "fusion"
        ]
        if luce_entries and any(_is_fiend_card(card) or "FAIRY" in str(card.metadata.get("race", "")).upper() for card in state.deck):
            other_field = False
            for zone, idx, card in state.field_cards():
                if card.cid != LUCE_DUSKS_DARK_CID:
                    other_field = True
                    break
            if not other_field:
                for zone_list in (state.field.stz, state.field.fz):
                    if any(zone_list):
                        other_field = True
                        break
            if other_field:
                derived.append("LUCE_TRIGGER")

    if (
        "SEQUENCE_20226_EQUIP" not in events
        and not state.opt_used.get(f"{FIENDSMITH_SEQUENCE_ALT_CID}:e1")
    ):
        has_sequence = any(
            card.cid == FIENDSMITH_SEQUENCE_ALT_CID for _zone, _idx, card in state.field_cards()
        )
        if has_sequence:
            for card in state.field.mz:
                if not card:
                    continue
                if not is_light_fiend_card(card):
                    continue
                if is_link_monster(card):
                    continue
                derived.append("SEQUENCE_20226_EQUIP")
                break

    if (
        "BUIO_GY_TRIGGER" not in events
        and not state.opt_used.get(f"{BUIO_DAWNS_LIGHT_CID}:e2")
        and BUIO_DAWNS_LIGHT_CID in state.last_moved_to_gy
    ):
        if any(card.cid == BUIO_DAWNS_LIGHT_CID for card in state.gy):
            derived.append("BUIO_GY_TRIGGER")

    if (
        "MUTINY_GY_TRIGGER" not in events
        and not state.opt_used.get(f"{MUTINY_IN_THE_SKY_CID}:e2")
        and MUTINY_IN_THE_SKY_CID in state.last_moved_to_gy
    ):
        if any(card.cid == MUTINY_IN_THE_SKY_CID for card in state.gy):
            derived.append("MUTINY_GY_TRIGGER")

    if not derived:
        return state

    new_state = state.clone()
    for evt in sorted(derived):
        if evt not in events:
            events.append(evt)
    new_state.events = events
    return new_state


def _equip_closure_pass(
    state: GameState,
    actions: list[Action | EffectAction],
    evaluation: dict[str, Any],
    prefer_longest: bool,
    depth: int = 2,
    beam_width: int = 10,
) -> SearchResult:
    best_result = SearchResult(actions=actions, final_state=state, evaluation=evaluation)
    seen = {state_hash(state)}
    beam = [(state, actions)]

    for _depth in range(depth):
        candidates = []
        for current_state, current_actions in beam:
            current_state = _add_derived_events(current_state)
            effect_actions = [
                action
                for action in enumerate_effect_actions(current_state)
                if action.effect_id in EQUIP_EFFECT_IDS
            ]
            effect_actions = sorted(effect_actions, key=lambda action: action.sort_key)
            for action in effect_actions:
                try:
                    new_state = apply_effect_action(current_state, action)
                except IllegalActionError:
                    continue
                new_state.last_moved_to_gy = _derive_last_moved_to_gy(current_state, new_state)
                new_state = _add_derived_events(new_state)
                key = state_hash(new_state)
                if key in seen:
                    continue
                seen.add(key)
                snapshot = game_state_to_endboard_snapshot(new_state)
                evaluation = evaluate_endboard(snapshot)
                candidates.append((new_state, current_actions + [action], evaluation))

        if not candidates:
            break

        candidates.sort(
            key=lambda item: (score_key(item[2]), state_hash(item[0])),
            reverse=True,
        )
        beam = [(state, actions) for state, actions, _eval in candidates[:beam_width]]

        best_candidate = candidates[0]
        if prefer_longest:
            if len(best_candidate[1]) >= len(best_result.actions):
                best_result = SearchResult(
                    actions=best_candidate[1],
                    final_state=best_candidate[0],
                    evaluation=best_candidate[2],
                )
        else:
            if score_key(best_candidate[2]) >= score_key(best_result.evaluation):
                best_result = SearchResult(
                    actions=best_candidate[1],
                    final_state=best_candidate[0],
                    evaluation=best_candidate[2],
                )

    return best_result


def search_best_line(
    state: GameState,
    max_depth: int = 2,
    beam_width: int = 10,
    allowed_actions: list[str] | None = None,
    prefer_longest: bool = False,
) -> SearchResult:
    if allowed_actions is None:
        allowed_actions = ["normal_summon", "special_summon", "extra_deck_summon"]

    state = _add_derived_events(state)
    initial_snapshot = game_state_to_endboard_snapshot(state)
    best_eval = evaluate_endboard(initial_snapshot)
    best_result = SearchResult(actions=[], final_state=state, evaluation=best_eval)

    seen = {state_hash(state)}
    beam = [(state, [])]

    for _depth in range(max_depth):
        candidates = []
        for current_state, actions in beam:
            current_state = _add_derived_events(current_state)
            core_actions = sorted(
                generate_actions(current_state, allowed_actions),
                key=core_action_sort_key,
            )
            effect_actions = enumerate_effect_actions(current_state)
            combined_actions: list[Action | EffectAction] = core_actions + effect_actions
            for action in combined_actions:
                try:
                    if isinstance(action, Action):
                        new_state = apply_action(current_state, action)
                    else:
                        new_state = apply_effect_action(current_state, action)
                except IllegalActionError:
                    continue
                new_state.last_moved_to_gy = _derive_last_moved_to_gy(current_state, new_state)
                new_state = _add_derived_events(new_state)
                key = state_hash(new_state)
                if key in seen:
                    continue
                seen.add(key)
                snapshot = game_state_to_endboard_snapshot(new_state)
                evaluation = evaluate_endboard(snapshot)
                candidates.append((new_state, actions + [action], evaluation))

        if not candidates:
            break

        candidates.sort(
            key=lambda item: (score_key(item[2]), state_hash(item[0])),
            reverse=True,
        )
        beam = [(state, actions) for state, actions, _eval in candidates[:beam_width]]

        best_candidate = candidates[0]
        if prefer_longest:
            if len(best_candidate[1]) >= len(best_result.actions):
                best_result = SearchResult(
                    actions=best_candidate[1],
                    final_state=best_candidate[0],
                    evaluation=best_candidate[2],
                )
        else:
            if score_key(best_candidate[2]) >= score_key(best_result.evaluation):
                best_result = SearchResult(
                    actions=best_candidate[1],
                    final_state=best_candidate[0],
                    evaluation=best_candidate[2],
                )

    best_result = _equip_closure_pass(
        best_result.final_state,
        best_result.actions,
        best_result.evaluation,
        prefer_longest,
    )
    return best_result
