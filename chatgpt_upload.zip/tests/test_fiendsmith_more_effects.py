import json
import subprocess
import sys
import unittest
from pathlib import Path

repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root / "src"))

from sim.effects.registry import apply_effect_action  # noqa: E402
from sim.effects.types import EffectAction  # noqa: E402
from sim.errors import IllegalActionError  # noqa: E402
from sim.state import GameState  # noqa: E402


def load_snapshot(report_path: Path) -> dict:
    content = report_path.read_text(encoding="utf-8")
    start = content.find("```json")
    if start == -1:
        raise AssertionError("Missing JSON block in report.")
    start = content.find("\n", start) + 1
    end = content.find("```", start)
    if end == -1:
        raise AssertionError("Unterminated JSON block in report.")
    return json.loads(content[start:end])


class TestFiendsmithMoreEffects(unittest.TestCase):
    def run_scenario(self, scenario_name: str) -> Path:
        scenario = repo_root / "tests" / "fixtures" / "combo_scenarios" / f"{scenario_name}.json"
        report = repo_root / "reports" / "combos" / f"{scenario_name}.md"
        if report.exists():
            report.unlink()
        result = subprocess.run(
            [
                sys.executable,
                str(repo_root / "scripts" / "combos" / "search_combo.py"),
                "--scenario",
                str(scenario),
            ],
            cwd=str(repo_root),
            text=True,
            capture_output=True,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(report.exists())
        return report

    def test_engraver_revive(self):
        report = self.run_scenario("fixture_engraver_revive")
        snapshot = load_snapshot(report)
        self.assertIn("Fiendsmith Engraver", snapshot["zones"]["field"])
        self.assertIn("Fiendsmith's Lacrima", snapshot["zones"]["deck"])

    def test_requiem_tribute_ss(self):
        report = self.run_scenario("fixture_requiem_tribute_ss")
        snapshot = load_snapshot(report)
        self.assertIn("Fiendsmith Engraver", snapshot["zones"]["field"])
        self.assertIn("Fiendsmith's Requiem", snapshot["zones"]["gy"])

    def test_requiem_fail_closed_on_no_open_mz(self):
        snapshot = {
            "zones": {
                "hand": [],
                "deck": [{"cid": "20196", "name": "Fiendsmith Engraver"}],
                "gy": [],
                "banished": [],
                "extra": [],
                "field_zones": {
                    "mz": [
                        {"cid": "20196", "name": "Fiendsmith Engraver"},
                        {"cid": "20196", "name": "Fiendsmith Engraver"},
                        {"cid": "20196", "name": "Fiendsmith Engraver"},
                        {"cid": "20196", "name": "Fiendsmith Engraver"},
                        {"cid": "20196", "name": "Fiendsmith Engraver"},
                    ],
                    "emz": [
                        {"cid": "20225", "name": "Fiendsmith's Requiem"},
                        None,
                    ],
                },
            }
        }
        state = GameState.from_snapshot(snapshot)
        action = EffectAction(
            cid="20225",
            name="Fiendsmith's Requiem",
            effect_id="tribute_self_ss_fiendsmith",
            params={
                "zone": "emz",
                "field_index": 0,
                "source": "deck",
                "source_index": 0,
                "mz_index": 0,
            },
            sort_key=("20225",),
        )
        with self.assertRaises(IllegalActionError):
            apply_effect_action(state, action)


if __name__ == "__main__":
    unittest.main()
