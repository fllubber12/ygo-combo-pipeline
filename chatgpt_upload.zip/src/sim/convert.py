from __future__ import annotations

from typing import Any

from .state import GameState


def game_state_to_endboard_snapshot(state: GameState) -> dict[str, Any]:
    field_cards = [card.name for card in state.field.mz if card]
    field_cards += [card.name for card in state.field.emz if card]

    return {
        "zones": {
            "hand": [card.name for card in state.hand],
            "field": field_cards,
            "gy": [card.name for card in state.gy],
            "banished": [card.name for card in state.banished],
            "deck": [card.name for card in state.deck],
            "extra": [card.name for card in state.extra],
        }
    }
