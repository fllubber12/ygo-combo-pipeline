from __future__ import annotations

from ..errors import IllegalActionError, SimModelError
from ..state import GameState
from .types import EffectAction, EffectImpl

FIENDSMITH_ENGRAVER_CID = "20196"
FIENDSMITH_TRACT_CID = "20240"
FIENDSMITH_REQUIEM_CID = "20225"

FIENDSMITH_ST_CIDS = {"20240", "20241", "20226", "20521", "20251", "20816"}
LIGHT_FIEND_MONSTER_CIDS = {"20196", "20214", "20215", "20225"}
FIENDSMITH_MONSTER_CIDS = {"20196", "20214"}


def is_fiendsmith_st(card_cid: str) -> bool:
    return card_cid in FIENDSMITH_ST_CIDS


def is_light_fiend_monster(card_cid: str) -> bool:
    return card_cid in LIGHT_FIEND_MONSTER_CIDS


class FiendsmithEngraverEffect(EffectImpl):
    def enumerate_actions(self, state: GameState) -> list[EffectAction]:
        actions: list[EffectAction] = []
        if not state.opt_used.get(f"{FIENDSMITH_ENGRAVER_CID}:e1"):
            for hand_index, card in enumerate(state.hand):
                if card.cid != FIENDSMITH_ENGRAVER_CID:
                    continue
                for deck_index, deck_card in enumerate(state.deck):
                    if not is_fiendsmith_st(deck_card.cid):
                        continue
                    actions.append(
                        EffectAction(
                            cid=FIENDSMITH_ENGRAVER_CID,
                            name=card.name,
                            effect_id="discard_search_fiendsmith_st",
                            params={"hand_index": hand_index, "deck_index": deck_index},
                            sort_key=(
                                FIENDSMITH_ENGRAVER_CID,
                                "discard_search_fiendsmith_st",
                                hand_index,
                                deck_index,
                            ),
                        )
                    )

        if not state.opt_used.get(f"{FIENDSMITH_ENGRAVER_CID}:e3"):
            open_mz = state.open_mz_indices()
            if open_mz:
                for gy_index, card in enumerate(state.gy):
                    if card.cid != FIENDSMITH_ENGRAVER_CID:
                        continue
                    for target_index, target in enumerate(state.gy):
                        if target_index == gy_index:
                            continue
                        if not is_light_fiend_monster(target.cid):
                            continue
                        for mz_index in open_mz:
                            actions.append(
                                EffectAction(
                                    cid=FIENDSMITH_ENGRAVER_CID,
                                    name=card.name,
                                    effect_id="gy_shuffle_light_fiend_then_ss_self",
                                    params={
                                        "gy_index": gy_index,
                                        "target_gy_index": target_index,
                                        "mz_index": mz_index,
                                    },
                                    sort_key=(
                                        FIENDSMITH_ENGRAVER_CID,
                                        "gy_shuffle_light_fiend_then_ss_self",
                                        gy_index,
                                        target_index,
                                        mz_index,
                                    ),
                                )
                            )
        return actions

    def apply(self, state: GameState, action: EffectAction) -> GameState:
        if action.effect_id != "discard_search_fiendsmith_st":
            if action.effect_id == "gy_shuffle_light_fiend_then_ss_self":
                return self._apply_gy_revive(state, action)
            raise SimModelError(f"Unmodeled effect_id: {action.effect_id}")
        if state.opt_used.get(f"{FIENDSMITH_ENGRAVER_CID}:e1"):
            raise IllegalActionError("Fiendsmith Engraver effect already used.")

        hand_index = action.params.get("hand_index")
        deck_index = action.params.get("deck_index")
        if hand_index is None or deck_index is None:
            raise SimModelError("Missing params for Fiendsmith Engraver effect.")

        if hand_index < 0 or hand_index >= len(state.hand):
            raise IllegalActionError("Hand index out of range for Fiendsmith Engraver.")
        if deck_index < 0 or deck_index >= len(state.deck):
            raise IllegalActionError("Deck index out of range for Fiendsmith Engraver.")

        if state.hand[hand_index].cid != FIENDSMITH_ENGRAVER_CID:
            raise SimModelError("Action does not match Fiendsmith Engraver card.")
        if not is_fiendsmith_st(state.deck[deck_index].cid):
            raise IllegalActionError("Selected deck card is not a Fiendsmith Spell/Trap.")

        new_state = state.clone()
        engraver = new_state.hand.pop(hand_index)
        new_state.gy.append(engraver)
        selected = new_state.deck.pop(deck_index)
        new_state.hand.append(selected)
        new_state.opt_used[f"{FIENDSMITH_ENGRAVER_CID}:e1"] = True
        return new_state

    def _apply_gy_revive(self, state: GameState, action: EffectAction) -> GameState:
        if state.opt_used.get(f"{FIENDSMITH_ENGRAVER_CID}:e3"):
            raise IllegalActionError("Fiendsmith Engraver GY effect already used.")

        gy_index = action.params.get("gy_index")
        target_index = action.params.get("target_gy_index")
        mz_index = action.params.get("mz_index")
        if gy_index is None or target_index is None or mz_index is None:
            raise SimModelError("Missing params for Fiendsmith Engraver GY effect.")

        if gy_index < 0 or gy_index >= len(state.gy):
            raise IllegalActionError("GY index out of range for Fiendsmith Engraver.")
        if target_index < 0 or target_index >= len(state.gy):
            raise IllegalActionError("Target GY index out of range for Fiendsmith Engraver.")
        if mz_index not in state.open_mz_indices():
            raise IllegalActionError("No open Main Monster Zone for Fiendsmith Engraver.")
        if gy_index == target_index:
            raise IllegalActionError("Target GY card must be different from Engraver.")

        if state.gy[gy_index].cid != FIENDSMITH_ENGRAVER_CID:
            raise SimModelError("Selected GY card is not Fiendsmith Engraver.")
        if not is_light_fiend_monster(state.gy[target_index].cid):
            raise IllegalActionError("Target GY card is not a LIGHT Fiend monster.")

        new_state = state.clone()
        indices = sorted([gy_index, target_index], reverse=True)
        removed = []
        for index in indices:
            removed.append(new_state.gy.pop(index))
        removed.reverse()
        engraver = removed[0] if gy_index < target_index else removed[1]
        target = removed[1] if gy_index < target_index else removed[0]
        new_state.deck.append(target)
        new_state.field.mz[mz_index] = engraver
        new_state.opt_used[f"{FIENDSMITH_ENGRAVER_CID}:e3"] = True
        return new_state


class FiendsmithTractEffect(EffectImpl):
    def enumerate_actions(self, state: GameState) -> list[EffectAction]:
        if state.opt_used.get(f"{FIENDSMITH_TRACT_CID}:e1"):
            return []

        actions: list[EffectAction] = []
        if len(state.hand) <= 1:
            return actions

        for hand_index, card in enumerate(state.hand):
            if card.cid != FIENDSMITH_TRACT_CID:
                continue
            for deck_index, deck_card in enumerate(state.deck):
                if not is_light_fiend_monster(deck_card.cid):
                    continue
                for discard_index in range(len(state.hand)):
                    if discard_index == hand_index:
                        continue
                    actions.append(
                        EffectAction(
                            cid=FIENDSMITH_TRACT_CID,
                            name=card.name,
                            effect_id="search_light_fiend_then_discard",
                            params={
                                "hand_index": hand_index,
                                "deck_index": deck_index,
                                "discard_hand_index": discard_index,
                            },
                            sort_key=(
                                FIENDSMITH_TRACT_CID,
                                "search_light_fiend_then_discard",
                                hand_index,
                                deck_index,
                                discard_index,
                            ),
                        )
                    )
        return actions

    def apply(self, state: GameState, action: EffectAction) -> GameState:
        if action.effect_id != "search_light_fiend_then_discard":
            raise SimModelError(f"Unmodeled effect_id: {action.effect_id}")
        if state.opt_used.get(f"{FIENDSMITH_TRACT_CID}:e1"):
            raise IllegalActionError("Fiendsmith's Tract effect already used.")

        hand_index = action.params.get("hand_index")
        deck_index = action.params.get("deck_index")
        discard_hand_index = action.params.get("discard_hand_index")
        if hand_index is None or deck_index is None or discard_hand_index is None:
            raise SimModelError("Missing params for Fiendsmith's Tract effect.")

        if hand_index < 0 or hand_index >= len(state.hand):
            raise IllegalActionError("Hand index out of range for Fiendsmith's Tract.")
        if deck_index < 0 or deck_index >= len(state.deck):
            raise IllegalActionError("Deck index out of range for Fiendsmith's Tract.")
        if discard_hand_index < 0 or discard_hand_index >= len(state.hand):
            raise IllegalActionError("Discard index out of range for Fiendsmith's Tract.")
        if discard_hand_index == hand_index:
            raise IllegalActionError("Discard choice cannot be the Tract itself.")

        if state.hand[hand_index].cid != FIENDSMITH_TRACT_CID:
            raise SimModelError("Action does not match Fiendsmith's Tract card.")
        if not is_light_fiend_monster(state.deck[deck_index].cid):
            raise IllegalActionError("Selected deck card is not a LIGHT Fiend monster.")

        new_state = state.clone()
        tract_card = new_state.hand.pop(hand_index)
        new_state.gy.append(tract_card)

        selected = new_state.deck.pop(deck_index)
        new_state.hand.append(selected)

        adjusted_discard_index = discard_hand_index
        if discard_hand_index > hand_index:
            adjusted_discard_index -= 1
        if adjusted_discard_index < 0 or adjusted_discard_index >= len(new_state.hand):
            raise IllegalActionError("Discard index invalid after Tract removal.")

        discarded = new_state.hand.pop(adjusted_discard_index)
        new_state.gy.append(discarded)

        new_state.opt_used[f"{FIENDSMITH_TRACT_CID}:e1"] = True
        return new_state


class FiendsmithRequiemEffect(EffectImpl):
    def enumerate_actions(self, state: GameState) -> list[EffectAction]:
        actions: list[EffectAction] = []
        open_mz = state.open_mz_indices()
        if not open_mz:
            return actions

        field_entries = []
        for index, card in enumerate(state.field.mz):
            if card and card.cid == FIENDSMITH_REQUIEM_CID:
                field_entries.append(("mz", index, card))
        for index, card in enumerate(state.field.emz):
            if card and card.cid == FIENDSMITH_REQUIEM_CID:
                field_entries.append(("emz", index, card))

        if not field_entries:
            return actions

        for zone, field_index, card in field_entries:
            for source_index, source_card in enumerate(state.hand):
                if source_card.cid not in FIENDSMITH_MONSTER_CIDS:
                    continue
                for mz_index in open_mz:
                    actions.append(
                        EffectAction(
                            cid=FIENDSMITH_REQUIEM_CID,
                            name=card.name,
                            effect_id="tribute_self_ss_fiendsmith",
                            params={
                                "zone": zone,
                                "field_index": field_index,
                                "source": "hand",
                                "source_index": source_index,
                                "mz_index": mz_index,
                            },
                            sort_key=(
                                FIENDSMITH_REQUIEM_CID,
                                "tribute_self_ss_fiendsmith",
                                zone,
                                field_index,
                                "hand",
                                source_index,
                                mz_index,
                            ),
                        )
                    )
            for source_index, source_card in enumerate(state.deck):
                if source_card.cid not in FIENDSMITH_MONSTER_CIDS:
                    continue
                for mz_index in open_mz:
                    actions.append(
                        EffectAction(
                            cid=FIENDSMITH_REQUIEM_CID,
                            name=card.name,
                            effect_id="tribute_self_ss_fiendsmith",
                            params={
                                "zone": zone,
                                "field_index": field_index,
                                "source": "deck",
                                "source_index": source_index,
                                "mz_index": mz_index,
                            },
                            sort_key=(
                                FIENDSMITH_REQUIEM_CID,
                                "tribute_self_ss_fiendsmith",
                                zone,
                                field_index,
                                "deck",
                                source_index,
                                mz_index,
                            ),
                        )
                    )

        return actions

    def apply(self, state: GameState, action: EffectAction) -> GameState:
        if action.effect_id != "tribute_self_ss_fiendsmith":
            raise SimModelError(f"Unmodeled effect_id: {action.effect_id}")

        zone = action.params.get("zone")
        field_index = action.params.get("field_index")
        source = action.params.get("source")
        source_index = action.params.get("source_index")
        mz_index = action.params.get("mz_index")
        if None in (zone, field_index, source, source_index, mz_index):
            raise SimModelError("Missing params for Fiendsmith's Requiem effect.")

        if zone not in {"mz", "emz"}:
            raise SimModelError("Invalid zone for Fiendsmith's Requiem effect.")
        if not isinstance(field_index, int) or not isinstance(source_index, int) or not isinstance(mz_index, int):
            raise SimModelError("Invalid index types for Fiendsmith's Requiem effect.")
        if mz_index not in state.open_mz_indices():
            raise IllegalActionError("No open Main Monster Zone for Fiendsmith's Requiem.")

        if zone == "mz":
            if field_index < 0 or field_index >= len(state.field.mz):
                raise IllegalActionError("Field index out of range for Requiem.")
            requiem = state.field.mz[field_index]
        else:
            if field_index < 0 or field_index >= len(state.field.emz):
                raise IllegalActionError("Field index out of range for Requiem.")
            requiem = state.field.emz[field_index]
        if not requiem or requiem.cid != FIENDSMITH_REQUIEM_CID:
            raise SimModelError("Selected field card is not Fiendsmith's Requiem.")

        if source == "hand":
            if source_index < 0 or source_index >= len(state.hand):
                raise IllegalActionError("Source index out of range for Requiem.")
            target = state.hand[source_index]
        elif source == "deck":
            if source_index < 0 or source_index >= len(state.deck):
                raise IllegalActionError("Source index out of range for Requiem.")
            target = state.deck[source_index]
        else:
            raise SimModelError("Invalid source for Fiendsmith's Requiem effect.")

        if target.cid not in FIENDSMITH_MONSTER_CIDS:
            raise IllegalActionError("Selected target is not a Fiendsmith monster.")

        new_state = state.clone()
        if zone == "mz":
            requiem_card = new_state.field.mz[field_index]
            new_state.field.mz[field_index] = None
        else:
            requiem_card = new_state.field.emz[field_index]
            new_state.field.emz[field_index] = None
        new_state.gy.append(requiem_card)

        if source == "hand":
            summoned = new_state.hand.pop(source_index)
        else:
            summoned = new_state.deck.pop(source_index)
        new_state.field.mz[mz_index] = summoned
        return new_state
