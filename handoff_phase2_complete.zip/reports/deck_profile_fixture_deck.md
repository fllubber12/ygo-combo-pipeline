# Deck Profile: fixture_deck

## Section Counts
- Main: 8
- Extra: 0
- Side: 0

## Main Deck Type Counts
- Monster: 4
- Spell: 3
- Trap: 1
- Unknown: 0

## Top 10 Most Numerous Cards
| Count | CID | Name |
| --- | --- | --- |
| 3 | 20196 | Fiendsmith Engraver |
| 2 | 20240 | Fiendsmith's Tract |
| 1 | 20816 | Fiendsmith Kyrie |
| 1 | 20225 | Fiendsmith's Requiem |
| 1 | 20241 | Fiendsmith's Sanct |

---
Dataset versions:
- card_library_sha256: 203558e0eae41cc4144e854d2c54b958f605a03114a433f55bb7ca4b00a2fd8c
- deck_json_sha256: 6619438d861e43e2d8433f653331b72ba7569a4e44305469b5367d2dcd038908
- git_commit: 8e08e03e6f3efae5e957394301b83034bc6626be
