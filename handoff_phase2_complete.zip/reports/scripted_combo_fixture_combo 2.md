# Scripted Combo Report: fixture_combo

## Action Log
- 1. move 'Fiendsmith's Desirae' hand -> field

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith's Desirae"
    ],
    "gy": [
      "Fiendsmith in Paradise"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  }
}
```

## Endboard Evaluation
- rank_key: (False, True, 1)
- summary: S=0 A=1 B=1
- achieved:
  - A card Fiendsmith's Desirae (zone=field)
  - B condition Fiendsmith in Paradise in GY (zone=gy)
