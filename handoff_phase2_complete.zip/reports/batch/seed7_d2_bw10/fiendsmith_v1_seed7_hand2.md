# Batch Combo Report: fiendsmith_v1_seed7_hand2

- seed: 7
- hand: 20251, 20241, 20241, 20490, 21625

## Core Actions
(none)

## Effect Actions
1. Fiendsmith's Sanct [20241] activate_sanct_token: {'hand_index': 1, 'mz_index': 0}
2. Fiendsmith's Sanct [20241] activate_sanct_token: {'hand_index': 1, 'mz_index': 1}

## Final Snapshot
```json
{
  "zones": {
    "hand": [
      "Fiendsmith in Paradise",
      "Lacrima the Crimson Tears",
      "Luce the Dusk's Dark"
    ],
    "field": [
      "Fiendsmith Token",
      "Fiendsmith Token"
    ],
    "gy": [
      "Fiendsmith's Sanct",
      "Fiendsmith's Sanct"
    ],
    "banished": [],
    "deck": [
      "The Duke of Demise",
      "Buio the Dawn's Light",
      "Lacrima the Crimson Tears",
      "Luce the Dusk's Dark",
      "Fiendsmith's Tract",
      "Mutiny in the Sky",
      "Fiendsmith's Tract",
      "Fiendsmith's Sanct",
      "Fiendsmith Engraver",
      "Buio the Dawn's Light",
      "Mutiny in the Sky",
      "Fiendsmith in Paradise",
      "Fiendsmith's Tract",
      "Mutiny in the Sky",
      "Fiendsmith in Paradise",
      "Fiendsmith Engraver",
      "Fiendsmith Engraver",
      "The Duke of Demise",
      "Lacrima the Crimson Tears",
      "Luce the Dusk's Dark",
      "Buio the Dawn's Light",
      "The Duke of Demise"
    ],
    "extra": [
      "Fiendsmith's Lacrima",
      "Fiendsmith's Desirae",
      "Necroquip Princess",
      "Aerial Eater",
      "Snake-Eyes Doomed Dragon",
      "Fiendsmith's Rextremende",
      "A Bao A Qu, the Lightless Shadow",
      "Fiendsmith Kyrie",
      "Fiendsmith's Requiem",
      "Fiendsmith's Sequence",
      "Fiendsmith's Sequence",
      "Fiendsmith's Agnumday",
      "Muckraker From the Underworld",
      "Cross-Sheep",
      "S:P Little Knight"
    ]
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (False, False, 0)
- summary: S=0 A=0 B=0
