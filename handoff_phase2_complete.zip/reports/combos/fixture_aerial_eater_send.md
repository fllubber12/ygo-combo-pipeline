# Combo Search Report: fixture_aerial_eater_send

## Core Actions
(none)

## Effect Actions
1. Aerial Eater [20427] aerial_eater_send: {'zone': 'mz', 'field_index': 0, 'deck_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Aerial Eater"
    ],
    "gy": [
      "Buio the Dawn's Light"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
