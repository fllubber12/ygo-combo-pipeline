# Combo Search Report: fixture_muckraker_revive

## Core Actions
(none)

## Effect Actions
1. Muckraker From the Underworld [17806] muckraker_discard_revive: {'zone': 'mz', 'field_index': 0, 'hand_index': 0, 'gy_index': 0, 'mz_index': 1}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Muckraker From the Underworld",
      "Buio the Dawn's Light"
    ],
    "gy": [
      "Discard Fodder"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
