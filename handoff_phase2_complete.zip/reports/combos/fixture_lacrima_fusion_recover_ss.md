# Combo Search Report: fixture_lacrima_fusion_recover_ss

## Core Actions
(none)

## Effect Actions
1. Fiendsmith's Lacrima [20214] lacrima_fusion_recover_light_fiend: {'field_zone': 'mz', 'field_index': 0, 'source_zone': 'gy', 'source_index': 0, 'mode': 'ss', 'mz_index': 1}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith's Lacrima",
      "Fiendsmith Engraver"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
