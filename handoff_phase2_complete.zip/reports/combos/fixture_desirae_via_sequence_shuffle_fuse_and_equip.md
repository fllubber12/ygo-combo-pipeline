# Combo Search Report: fixture_desirae_via_sequence_shuffle_fuse_and_equip

## Core Actions
(none)

## Effect Actions
1. Fiendsmith's Sequence [20238] sequence_shuffle_fuse_fiend: {'seq_zone': 'emz', 'seq_index': 0, 'extra_index': 0, 'mz_index': 0, 'gy_indices': [0, 1, 2]}
2. Fiendsmith's Sequence [20238] equip_sequence_to_fiend: {'source': 'emz', 'source_index': 0, 'target_mz_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith's Desirae"
    ],
    "gy": [],
    "banished": [],
    "deck": [
      "Fiendsmith Engraver",
      "Light Fiend A",
      "Light Fiend B"
    ],
    "extra": []
  },
  "equipped_link_totals": [
    {
      "name": "Fiendsmith's Desirae",
      "total": 2
    }
  ]
}
```

## Endboard Evaluation
- rank_key: (1, 1, 0)
- summary: S=1 A=1 B=0
- achieved:
  - A card Fiendsmith's Desirae (zone=field)
  - S condition Desirae equipped link (zone=field)
