# Combo Search Report: fixture_sp_little_knight_inert

## Core Actions
(none)

## Effect Actions
(none)

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "S:P Little Knight"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (False, False, 1)
- summary: S=0 A=0 B=1
- achieved:
  - B card S:P Little Knight (zone=field)
