# Combo Search Report: fixture_abao_revive_sequence_equip

## Core Actions
(none)

## Effect Actions
1. A Bao A Qu, the Lightless Shadow [20786] abao_discard_banish_revive: {'zone': 'emz', 'field_index': 0, 'hand_index': 0, 'gy_index': 1, 'mz_index': 0}
2. Fiendsmith's Sequence [20226] sequence_20226_equip: {'source': 'gy', 'source_index': 0, 'target_mz_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith Engraver"
    ],
    "gy": [
      "Discard Fodder"
    ],
    "banished": [
      "A Bao A Qu, the Lightless Shadow"
    ],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": [
    {
      "name": "Fiendsmith Engraver",
      "total": 2
    }
  ]
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
