# Combo Search Report: fixture_kyrie_gy_fuse_rextremende

## Core Actions
(none)

## Effect Actions
1. Fiendsmith Kyrie [20816] kyrie_gy_banish_fuse: {'gy_index': 0, 'extra_index': 0, 'mz_index': 1, 'materials': [{'source': 'mz', 'index': 0}, {'source': 'emz', 'index': 0}]}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith's Rextremende"
    ],
    "gy": [
      "Fiendsmith's Desirae",
      "Fiendsmith's Sequence"
    ],
    "banished": [
      "Fiendsmith Kyrie"
    ],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 2)
- summary: S=0 A=0 B=2
- achieved:
  - B card Fiendsmith's Rextremende (zone=field)
  - B condition Fiendsmith's Sequence in GY (zone=gy)
