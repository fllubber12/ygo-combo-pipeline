# Combo Search Report: fixture_caesar_negate_send

## Core Actions
(none)

## Effect Actions
1. D/D/D Wave High King Caesar [13081] caesar_negate_send: {'zone': 'mz', 'field_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "D/D/D Wave High King Caesar"
    ],
    "gy": [
      "Opponent Card"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (1, 0, 0)
- summary: S=1 A=0 B=0
- achieved:
  - S card D/D/D Wave High King Caesar (zone=field)
