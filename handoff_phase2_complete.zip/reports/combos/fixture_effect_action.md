# Combo Search Report: fixture_effect_action

## Core Actions
(none)

## Effect Actions
(none)

## Final Snapshot
```json
{
  "zones": {
    "hand": [
      "Demo Extender"
    ],
    "field": [],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
