# Combo Search Report: fixture_buio_gy_mutiny_luce_chain

## Core Actions
(none)

## Effect Actions
1. Buio the Dawn's Light [21624] buio_gy_search_mutiny: {'buio_gy_index': 0, 'deck_index': 0}
2. Mutiny in the Sky [21626] mutiny_fusion_summon: {'hand_index': 0, 'extra_index': 0, 'mz_index': 0, 'gy_indices': [0, 1]}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Luce the Dusk's Dark"
    ],
    "gy": [
      "Mutiny in the Sky"
    ],
    "banished": [],
    "deck": [
      "Buio the Dawn's Light"
    ],
    "extra": [
      "Aerial Eater"
    ]
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
