# Combo Search Report: fixture_kyrie_in_gy

## Core Actions
(none)

## Effect Actions
1. Fiendsmith Engraver [20196] discard_search_fiendsmith_st: {'hand_index': 0, 'deck_index': 0}
2. Fiendsmith's Tract [20240] search_light_fiend_then_discard: {'hand_index': 0, 'deck_index': 0, 'discard_hand_index': 1}

## Final Snapshot
```json
{
  "zones": {
    "hand": [
      "Fiendsmith's Lacrima"
    ],
    "field": [],
    "gy": [
      "Fiendsmith Engraver",
      "Fiendsmith's Tract",
      "Fiendsmith Kyrie"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 1)
- summary: S=0 A=0 B=1
- achieved:
  - B condition Fiendsmith Kyrie in GY (zone=gy)
