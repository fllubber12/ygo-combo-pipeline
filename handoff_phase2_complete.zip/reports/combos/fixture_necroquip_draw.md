# Combo Search Report: fixture_necroquip_draw

## Core Actions
(none)

## Effect Actions
1. Necroquip Princess [20423] necroquip_draw: {'zone': 'mz', 'field_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [
      "Draw Fodder"
    ],
    "field": [
      "Necroquip Princess"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
