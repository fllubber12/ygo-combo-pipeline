# Combo Search Report: fixture_sequence_20226_equip

## Core Actions
(none)

## Effect Actions
1. Fiendsmith's Sequence [20226] sequence_20226_equip: {'source': 'emz', 'source_index': 0, 'target_mz_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith Engraver"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": [
    {
      "name": "Fiendsmith Engraver",
      "total": 2
    }
  ]
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
