# Combo Search Report: fixture_rextremende_send_light_fiend

## Core Actions
(none)

## Effect Actions
1. Fiendsmith's Rextremende [20774] rextremende_discard_send_light_fiend: {'mz_index': 0, 'hand_index': 0, 'send_source': 'deck', 'send_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith's Rextremende"
    ],
    "gy": [
      "Discard Fodder",
      "Fiendsmith Engraver"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 1)
- summary: S=0 A=0 B=1
- achieved:
  - B card Fiendsmith's Rextremende (zone=field)
