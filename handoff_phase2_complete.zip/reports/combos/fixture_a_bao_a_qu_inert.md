# Combo Search Report: fixture_a_bao_a_qu_inert

## Core Actions
(none)

## Effect Actions
(none)

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "A Bao A Qu, the Lightless Shadow"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (False, False, 1)
- summary: S=0 A=0 B=1
- achieved:
  - B card A Bao A Qu, the Lightless Shadow (zone=field)
