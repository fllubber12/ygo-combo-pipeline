# Combo Search Report: fixture_buio_hand_ss

## Core Actions
(none)

## Effect Actions
1. Buio the Dawn's Light [21624] buio_hand_ss: {'hand_index': 0, 'target_mz_index': 0, 'mz_index': 1}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith Engraver",
      "Buio the Dawn's Light"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
