# Combo Search Report: fixture_engraver_revive

## Core Actions
(none)

## Effect Actions
1. Fiendsmith Engraver [20196] gy_shuffle_light_fiend_then_ss_self: {'gy_index': 0, 'target_gy_index': 1, 'mz_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith Engraver"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": [
      "Fiendsmith's Lacrima"
    ]
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
