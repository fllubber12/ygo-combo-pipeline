# Combo Search Report: fixture_paradise_gy_send_rextremende

## Core Actions
(none)

## Effect Actions
1. Fiendsmith in Paradise [20251] paradise_gy_banish_send_fiendsmith: {'gy_index': 0, 'send_source': 'extra', 'send_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [],
    "gy": [
      "Fiendsmith's Rextremende"
    ],
    "banished": [
      "Fiendsmith in Paradise"
    ],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
