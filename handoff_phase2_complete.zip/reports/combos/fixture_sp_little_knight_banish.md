# Combo Search Report: fixture_sp_little_knight_banish

## Core Actions
(none)

## Effect Actions
1. S:P Little Knight [19188] sp_little_knight_banish: {'zone': 'mz', 'field_index': 0, 'target_zone': 'stz', 'target_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "S:P Little Knight"
    ],
    "gy": [],
    "banished": [
      "Opponent Card"
    ],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 1)
- summary: S=0 A=0 B=1
- achieved:
  - B card S:P Little Knight (zone=field)
