# Combo Search Report: fixture_requiem_link_summon

## Core Actions
1. extra_deck_summon: {'extra_index': 0, 'summon_type': 'link', 'materials': [('mz', 0)], 'min_materials': 1, 'link_rating': 1}

## Effect Actions
(none)

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith's Requiem"
    ],
    "gy": [
      "Material A"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  }
}
```

## Endboard Evaluation
- rank_key: (False, False, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
