# Combo Search Report: fixture_oppturn_agnumday_revive_desirae

## Core Actions
(none)

## Effect Actions
1. Fiendsmith's Lacrima [20490] gy_shuffle_ss_fiendsmith_link: {'gy_index': 0, 'target_gy_index': 1, 'emz_index': 0}
2. Fiendsmith's Agnumday [20521] agnumday_revive_equip: {'zone': 'emz', 'field_index': 0, 'gy_index': 0, 'mz_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith's Desirae"
    ],
    "gy": [],
    "banished": [],
    "deck": [
      "Fiendsmith's Lacrima"
    ],
    "extra": []
  },
  "equipped_link_totals": [
    {
      "name": "Fiendsmith's Desirae",
      "total": 3
    }
  ]
}
```

## Endboard Evaluation
- rank_key: (1, 1, 0)
- summary: S=1 A=1 B=0
- achieved:
  - A card Fiendsmith's Desirae (zone=field)
  - S condition Desirae equipped link (zone=field)
