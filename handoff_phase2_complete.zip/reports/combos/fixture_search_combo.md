# Combo Search Report: fixture_search_combo

## Core Actions
1. extra_deck_summon: {'extra_index': 0, 'summon_type': 'xyz', 'materials': [('mz', 0), ('mz', 1)], 'min_materials': 2, 'link_rating': None}

## Effect Actions
(none)

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "D/D/D Wave High King Caesar"
    ],
    "gy": [
      "Material A",
      "Material B"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (1, 0, 0)
- summary: S=1 A=0 B=0
- achieved:
  - S card D/D/D Wave High King Caesar (zone=field)
