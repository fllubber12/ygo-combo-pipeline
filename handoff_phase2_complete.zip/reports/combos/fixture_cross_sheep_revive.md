# Combo Search Report: fixture_cross_sheep_revive

## Core Actions
(none)

## Effect Actions
1. Cross-Sheep [14856] cross_sheep_revive: {'zone': 'mz', 'field_index': 0, 'gy_index': 0, 'mz_index': 1}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Cross-Sheep",
      "Buio the Dawn's Light"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
