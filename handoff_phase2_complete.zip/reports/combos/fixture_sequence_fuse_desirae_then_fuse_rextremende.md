# Combo Search Report: fixture_sequence_fuse_desirae_then_fuse_rextremende

## Core Actions
(none)

## Effect Actions
1. Fiendsmith's Sequence [20238] sequence_shuffle_fuse_rextremende: {'seq_zone': 'emz', 'seq_index': 0, 'extra_index': 0, 'mz_index': 0, 'gy_indices': [0, 1]}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith's Rextremende",
      "Dummy 1",
      "Dummy 2",
      "Dummy 3",
      "Dummy 4",
      "Fiendsmith's Sequence"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": [
      "Fiendsmith's Desirae",
      "Generic Link Material"
    ]
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 2)
- summary: S=0 A=0 B=2
- achieved:
  - B card Fiendsmith's Rextremende (zone=field)
  - B card Fiendsmith's Sequence (zone=field)
