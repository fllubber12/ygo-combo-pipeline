# Combo Search Report: fixture_muckraker_inert

## Core Actions
(none)

## Effect Actions
(none)

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Muckraker From the Underworld"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (False, False, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
