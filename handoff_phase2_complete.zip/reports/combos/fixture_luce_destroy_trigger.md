# Combo Search Report: fixture_luce_destroy_trigger

## Core Actions
(none)

## Effect Actions
1. Luce the Dusk's Dark [21625] luce_destroy_card: {'zone': 'mz', 'field_index': 0, 'target_zone': 'stz', 'target_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Luce the Dusk's Dark"
    ],
    "gy": [
      "Opponent Card"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
