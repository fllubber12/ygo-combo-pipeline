# Combo Search Report: fixture_abao_revive

## Core Actions
(none)

## Effect Actions
1. A Bao A Qu, the Lightless Shadow [20786] abao_discard_banish_revive: {'zone': 'mz', 'field_index': 0, 'hand_index': 0, 'gy_index': 0, 'mz_index': 1}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Buio the Dawn's Light"
    ],
    "gy": [
      "Discard Fodder"
    ],
    "banished": [
      "A Bao A Qu, the Lightless Shadow"
    ],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
