# Combo Search Report: fixture_requiem_tribute_ss

## Core Actions
(none)

## Effect Actions
1. Fiendsmith's Requiem [20225] tribute_self_ss_fiendsmith: {'zone': 'emz', 'field_index': 0, 'source': 'deck', 'source_index': 0, 'mz_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Lacrima the Crimson Tears"
    ],
    "gy": [
      "Fiendsmith's Requiem"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 1)
- summary: S=0 A=0 B=1
- achieved:
  - B condition Fiendsmith's Requiem in GY (zone=gy)
