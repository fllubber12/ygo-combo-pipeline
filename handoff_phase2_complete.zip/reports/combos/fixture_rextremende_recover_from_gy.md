# Combo Search Report: fixture_rextremende_recover_from_gy

## Core Actions
(none)

## Effect Actions
1. Fiendsmith's Tract [20774] gy_rextremende_recover_fiendsmith: {'rext_gy_index': 0, 'target_zone': 'banished', 'target_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [
      "Fiendsmith's Tract"
    ],
    "field": [],
    "gy": [
      "Fiendsmith's Rextremende"
    ],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
