# Combo Search Report: fixture_desirae_equip_closure_s

## Core Actions
(none)

## Effect Actions
1. Fiendsmith's Requiem [20225] equip_requiem_to_fiend: {'source': 'gy', 'source_index': 0, 'target_mz_index': 0}

## Final Snapshot
```json
{
  "zones": {
    "hand": [],
    "field": [
      "Fiendsmith's Desirae"
    ],
    "gy": [],
    "banished": [],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": [
    {
      "name": "Fiendsmith's Desirae",
      "total": 1
    }
  ]
}
```

## Endboard Evaluation
- rank_key: (1, 1, 0)
- summary: S=1 A=1 B=0
- achieved:
  - A card Fiendsmith's Desirae (zone=field)
  - S condition Desirae equipped link (zone=field)
