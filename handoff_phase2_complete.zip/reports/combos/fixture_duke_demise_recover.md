# Combo Search Report: fixture_duke_demise_recover

## Core Actions
(none)

## Effect Actions
1. The Duke of Demise [20389] duke_demise_banish_recover: {'duke_gy_index': 0, 'target_gy_index': 1}

## Final Snapshot
```json
{
  "zones": {
    "hand": [
      "Fiendsmith Engraver"
    ],
    "field": [],
    "gy": [],
    "banished": [
      "The Duke of Demise"
    ],
    "deck": [],
    "extra": []
  },
  "equipped_link_totals": []
}
```

## Endboard Evaluation
- rank_key: (0, 0, 0)
- summary: S=0 A=0 B=0
- achieved:
  - (none)
