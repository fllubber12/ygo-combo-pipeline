# Changelog

## Simulation Rules Patch
- Clarified PSCT parsing contract to CONDITION : ACTIVATION ; RESOLUTION and anchored to the official Konami terminology PDF.
- Updated normal summon/set tracking to a shared budget, plus extra deck placement rules and link-material counting constraints.
- Expanded coverage matrix and acceptance tests to match the rule-critical combo legality checks.
